/*-------------------------------------------------------------------------
 *
 * firstvalues.h
 *
 *	  Interface for first_values aggregate and support functionality
 *
 * Copyright (c) 2018, PipelineDB, Inc.
 *
 *-------------------------------------------------------------------------
 */
#ifndef FIRSTVALUES_H
#define FIRSTVALUES_H


#endif
