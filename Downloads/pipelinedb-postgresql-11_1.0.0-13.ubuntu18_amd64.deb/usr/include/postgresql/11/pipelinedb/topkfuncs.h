/*-------------------------------------------------------------------------
 *
 * topkfuncs.h
 *
 * Copyright (c) 2018, PipelineDB, Inc.
 *
 *-------------------------------------------------------------------------
 */
#ifndef TOPKFUNCS_H
#define TOPKFUNCS_H

#include "postgres.h"
#include "fmgr.h"

#define TOPK_TYPENAME "topk"

#endif
